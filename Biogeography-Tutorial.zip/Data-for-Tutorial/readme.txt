###Read Me File###

These files were collated by Jacob C. Cooper (https://orcid.org/0000-0003-2182-3236) for use in Biogeography, taught at the University of Chicago.

This folder contains files that have been published or will be published by Jacob C. Cooper and his collaborators.

If you wish to use any of these data, please contact Jacob C. Cooper at black [dot] hawk [dot] birder [at] gmail [dot] com

Data that are publicly available from the publications will be listed as such within the publication.
